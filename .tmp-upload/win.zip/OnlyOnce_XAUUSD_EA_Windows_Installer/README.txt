OnlyOnce XAUUSD EA RR2.5 - Windows Installer
============================================

Files included:
- OnlyOnce_XAUUSD_EA.ex5
- Install_OnlyOnce_XAUUSD_EA.bat

How to install:
1. Extract this ZIP file.
2. Double-click Install_OnlyOnce_XAUUSD_EA.bat.
3. Restart MetaTrader 5.
4. In MT5, open Navigator.
5. Right-click Expert Advisors, then click Refresh.
6. Open OnlyOnceEA.
7. Drag OnlyOnce_XAUUSD_EA onto the XAUUSD H1 chart.
8. Turn on Algo Trading.

Important WebRequest setting:
1. In MT5, click Tools > Options.
2. Open the Expert Advisors tab.
3. Tick "Allow WebRequest for listed URL".
4. Add this URL:
   https://onlyoncetrade.com
5. Click OK.

License:
This EA uses OnlyOnce remote UID authorization.
If the MT5 UID is not authorized or expired, the EA will show LOCKED and will not trade.

Safety:
The installer only copies EA files into MetaTrader 5 folders.
It does not ask for MT5 passwords, broker passwords, bank card details, exchange API keys, or seed phrases.
