OnlyOnce XAUUSD EA RR2.5 - Mac Installer
========================================

Files included:
- Install OnlyOnce XAUUSD EA Mac.command
- OnlyOnce XAUUSD EA.ex5

How to install:
1. Unzip this package.
2. Make sure all files stay in the same folder.
3. Right-click "Install OnlyOnce XAUUSD EA Mac.command".
4. Choose Open, then confirm Open.
5. Open MetaTrader 5.
6. Right-click Expert Advisors and click Refresh.
7. Open OnlyOnceEA.
8. Drag OnlyOnce_XAUUSD_EA onto the XAUUSD H1 chart.
9. Turn on Algo Trading.

Important WebRequest setting:
1. In MT5, click Tools > Options.
2. Open the Expert Advisors tab.
3. Tick "Allow WebRequest for listed URL".
4. Add this URL:
   https://onlyoncetrade.com
5. Click OK.

License:
This EA uses OnlyOnce remote UID authorization.
If the MT5 UID is not authorized or expired, the EA will show LOCKED and will not trade.

Safety:
The installer only copies EA files into MetaTrader 5 folders.
It does not ask for MT5 passwords, broker passwords, bank card details, exchange API keys, or seed phrases.
