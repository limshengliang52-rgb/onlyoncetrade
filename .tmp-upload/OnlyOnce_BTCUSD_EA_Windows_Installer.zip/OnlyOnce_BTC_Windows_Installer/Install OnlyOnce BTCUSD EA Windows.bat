@echo off
setlocal
title Install OnlyOnce BTCUSD EA

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%Install OnlyOnce BTCUSD EA Windows.ps1"

echo.
pause
