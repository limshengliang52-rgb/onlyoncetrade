OnlyOnce BTCUSD EA Windows Installer
====================================

Files included:
- Install OnlyOnce BTCUSD EA Windows.bat
- Install OnlyOnce BTCUSD EA Windows.ps1
- OnlyOnce BTCUSD EA.ex5

How to install:
1. Unzip this package.
2. Keep all files in the same folder.
3. Double-click "Install OnlyOnce BTCUSD EA Windows.bat".
4. Open MetaTrader 5.
5. Right-click Expert Advisors and click Refresh.
6. Open the OnlyOnceEA folder.
7. Drag OnlyOnce BTCUSD EA onto a BTCUSD chart.
8. Turn on Algo Trading.

The installer only copies the EA file into your MT5 Experts folder.
It does not ask for MT5 passwords, broker passwords, bank card details,
exchange API keys, or seed phrases.
