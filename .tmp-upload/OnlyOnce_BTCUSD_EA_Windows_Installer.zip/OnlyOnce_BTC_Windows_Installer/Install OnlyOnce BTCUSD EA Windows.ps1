$ErrorActionPreference = "Stop"

$eaFileName = "OnlyOnce BTCUSD EA.ex5"
$eaFolderName = "OnlyOnceEA"
$sourceEa = Join-Path $PSScriptRoot $eaFileName

Write-Host ""
Write-Host "OnlyOnce BTCUSD EA Installer" -ForegroundColor Cyan
Write-Host "----------------------------"

if (-not (Test-Path $sourceEa)) {
    Write-Host "EA file not found beside installer:" -ForegroundColor Red
    Write-Host $sourceEa
    exit 1
}

$terminalRoot = Join-Path $env:APPDATA "MetaQuotes\Terminal"
if (-not (Test-Path $terminalRoot)) {
    Write-Host "MT5 data folder not found:" -ForegroundColor Red
    Write-Host $terminalRoot
    Write-Host "Please install/open MetaTrader 5 first, then run this installer again."
    exit 1
}

$expertTargets = Get-ChildItem -Path $terminalRoot -Directory |
    ForEach-Object {
        $experts = Join-Path $_.FullName "MQL5\Experts"
        if (Test-Path $experts) { $experts }
    }

if (-not $expertTargets -or $expertTargets.Count -eq 0) {
    Write-Host "No MT5 MQL5\Experts folder found." -ForegroundColor Red
    Write-Host "Please open MT5 once first, then run this installer again."
    exit 1
}

$installed = @()
foreach ($experts in $expertTargets) {
    $brandFolder = Join-Path $experts $eaFolderName
    New-Item -ItemType Directory -Path $brandFolder -Force | Out-Null
    $dest = Join-Path $brandFolder $eaFileName
    Copy-Item -Path $sourceEa -Destination $dest -Force
    $installed += $dest
}

Write-Host ""
Write-Host "Installed successfully:" -ForegroundColor Green
foreach ($path in $installed) {
    Write-Host " - $path"
}

Write-Host ""
Write-Host "Next steps:"
Write-Host "1. Open MetaTrader 5."
Write-Host "2. Right-click Expert Advisors, then click Refresh."
Write-Host "3. Open OnlyOnceEA."
Write-Host "4. Drag OnlyOnce BTCUSD EA to BTCUSD chart."
Write-Host "5. Turn on Algo Trading."
Write-Host ""
