@echo off
setlocal
title OnlyOnce XAUUSD EA Installer

set "EA_FILE=%~dp0OnlyOnce_XAUUSD_EA.ex5"

echo.
echo ==========================================
echo        OnlyOnce XAUUSD EA Installer
echo ==========================================
echo.

if not exist "%EA_FILE%" (
  echo ERROR: OnlyOnce_XAUUSD_EA.ex5 was not found in this folder.
  echo Please keep this installer and the EX5 file in the same folder.
  echo.
  pause
  exit /b 1
)

set "FOUND=0"

for /d %%D in ("%APPDATA%\MetaQuotes\Terminal\*") do (
  if exist "%%D\MQL5\Experts" (
    echo Installing to:
    echo %%D\MQL5\Experts
    copy /Y "%EA_FILE%" "%%D\MQL5\Experts\OnlyOnce_XAUUSD_EA.ex5" >nul
    set "FOUND=1"
    echo Done.
    echo.
  )
)

if "%FOUND%"=="0" (
  echo MT5 data folder was not found automatically.
  echo.
  echo Please open MT5, click:
  echo File ^> Open Data Folder ^> MQL5 ^> Experts
  echo.
  echo Then copy OnlyOnce_XAUUSD_EA.ex5 into the Experts folder.
  echo.
  pause
  exit /b 1
)

echo Installation completed.
echo.
echo Next steps:
echo 1. Restart MetaTrader 5.
echo 2. Open Navigator.
echo 3. Right click Expert Advisors and click Refresh.
echo 4. Drag OnlyOnce_XAUUSD_EA onto XAUUSD chart.
echo 5. Allow Algo Trading.
echo 6. Allow WebRequest URL: https://onlyoncetrade.com
echo.
pause
