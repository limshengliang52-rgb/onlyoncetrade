OnlyOnce XAUUSD EA - Windows Installer

Files included:
- OnlyOnce_XAUUSD_EA.ex5
- Install_OnlyOnce_XAUUSD_EA.bat

How to install:
1. Extract this folder.
2. Double click Install_OnlyOnce_XAUUSD_EA.bat.
3. Restart MetaTrader 5.
4. In MT5, open Navigator.
5. Right click Expert Advisors, then click Refresh.
6. Drag OnlyOnce_XAUUSD_EA onto the XAUUSD chart.
7. Turn on Algo Trading.

Important WebRequest setting:
1. In MT5, click Tools > Options.
2. Open the Expert Advisors tab.
3. Tick "Allow WebRequest for listed URL".
4. Add this URL:
   https://onlyoncetrade.com
5. Click OK.

Note:
This EA uses OnlyOnce remote license authorization.
If your account is not authorized or expired, the EA will show LOCKED and will not trade.
