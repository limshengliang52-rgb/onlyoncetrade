OnlyOnce XAUUSD EA Mac Installer
================================

Files included:
- Install OnlyOnce XAUUSD EA Mac.command
- OnlyOnce XAUUSD EA.ex5

How to install:
1. Unzip this package.
2. Make sure both files stay in the same folder.
3. Double-click "Install OnlyOnce XAUUSD EA Mac.command".
4. Open MetaTrader 5.
5. Right-click Expert Advisors and click Refresh.
6. Open the OnlyOnceEA folder.
7. Drag the XAUUSD EA onto an XAUUSD chart.
8. Turn on Algo Trading.

If macOS blocks the installer:
Right-click the .command file, choose Open, then confirm Open.

The installer only copies the EA file into your MT5 Experts folder.
It does not ask for MT5 passwords, broker passwords, bank card details,
exchange API keys, or seed phrases.
