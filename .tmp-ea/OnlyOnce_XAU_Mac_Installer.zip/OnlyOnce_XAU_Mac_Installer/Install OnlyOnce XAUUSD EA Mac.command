#!/bin/bash
set -e

EA_FILE="OnlyOnce XAUUSD EA.ex5"
EA_FOLDER="OnlyOnceEA"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_EA="$SCRIPT_DIR/$EA_FILE"

echo ""
echo "OnlyOnce XAUUSD EA Installer for Mac"
echo "------------------------------------"

if [ ! -f "$SOURCE_EA" ]; then
  echo "EA file not found beside installer:"
  echo "$SOURCE_EA"
  exit 1
fi

declare -a ROOTS=(
  "$HOME/Library/Application Support/MetaQuotes/Terminal"
  "$HOME/Library/Application Support/net.metaquotes.wine.metatrader5/drive_c/users/$USER/AppData/Roaming/MetaQuotes/Terminal"
  "$HOME/Library/Application Support/CrossOver/Bottles"
  "$HOME/Library/Application Support/com.codeweavers.CrossOver/Bottles"
)

declare -a TARGETS=()

for root in "${ROOTS[@]}"; do
  if [ -d "$root" ]; then
    while IFS= read -r experts; do
      TARGETS+=("$experts")
    done < <(find "$root" -type d -path "*/MQL5/Experts" 2>/dev/null)
  fi
done

if [ "${#TARGETS[@]}" -eq 0 ]; then
  echo "No MT5 MQL5/Experts folder found automatically."
  echo ""
  echo "Please open MT5 once first, then run this installer again."
  echo "If it still cannot find MT5, manually copy:"
  echo "$EA_FILE"
  echo "into:"
  echo "MQL5/Experts/OnlyOnceEA"
  echo ""
  read -n 1 -s -r -p "Press any key to close..."
  echo ""
  exit 1
fi

echo ""
echo "Found MT5 Experts folders:"
for experts in "${TARGETS[@]}"; do
  brand_folder="$experts/$EA_FOLDER"
  mkdir -p "$brand_folder"
  cp -f "$SOURCE_EA" "$brand_folder/$EA_FILE"
  echo " - $brand_folder/$EA_FILE"
done

echo ""
echo "Installed successfully."
echo ""
echo "Next steps:"
echo "1. Open MetaTrader 5."
echo "2. Right-click Expert Advisors, then click Refresh."
echo "3. Open OnlyOnceEA."
echo "4. Drag OnlyOnce XAUUSD EA to XAUUSD chart."
echo "5. Turn on Algo Trading."
echo ""
read -n 1 -s -r -p "Press any key to close..."
echo ""
