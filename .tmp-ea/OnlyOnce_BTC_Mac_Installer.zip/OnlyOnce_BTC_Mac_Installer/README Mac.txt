Only once EA BTC USD - Mac Installer

How to install on Mac:
1. Extract this ZIP file.
2. Right-click "Install Only once EA BTC USD Mac.command".
3. Click Open.
4. If macOS blocks it, open System Settings > Privacy & Security and allow it.
5. The installer will search common MT5/Wine/CrossOver folders.
6. Open MetaTrader 5.
7. Right-click Expert Advisors and click Refresh.
8. Open the OnlyOnceEA folder.
9. Drag "Only once EA BTC USD" to BTCUSD chart.
10. Turn on Algo Trading.

Important:
Mac MT5 paths can be different depending on installation method. For stable live trading, Windows VPS is still recommended.
